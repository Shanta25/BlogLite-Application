import checksumdir
hash = checksumdir.dirhash("Project")
print(hash)