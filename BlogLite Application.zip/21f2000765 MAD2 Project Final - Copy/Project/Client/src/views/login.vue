<template>
    <div>
      <h2>Login</h2>
      <form @submit.prevent="login" method="post">
        <div>
          <label for="username">Username</label>
          <input id="username" v-model="username" type="text">
        </div>
        <div>
          <label for="password">Password</label>
          <input id="password" v-model="password" type="password">
        </div>
        <button type="submit">Login</button>
      </form>
      <p>Response is {{ message }}</p>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        username: '',
        password: '',
        message: ''
      };
    },
    methods: {
      login() {
        axios.post('http://127.0.0.1:5000/login', {
          username: this.username,
          password: this.password
        })
        .then(response => {
        this.message = response.status;
      })
      .catch(error => {
        this.message = error.response.data;
      });
      }
    }
  }
  </script>
  