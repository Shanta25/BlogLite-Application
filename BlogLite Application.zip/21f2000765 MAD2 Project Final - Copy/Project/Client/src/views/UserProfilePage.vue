<template>
  <div class="userprofile">
    <Navbar />
    <title> User Profile of {{ user_info.username }} </title>

    <h1>User: {{ user_info.username }} </h1>
    <h2>Email: {{ user_info.email }} </h2>
    <hr>

    <p> {{ followerslength }} followers, {{ followinglength }} following</p>
    <div v-if="user_info.username == current_username">
      <div class="col-md-2">
        <a href="/updateprofile" class="btn" style="border-radius: 15px; 
            background: linear-gradient(117.5deg, rgb(89, 233, 162) 20.5%, rgb(29, 209, 185) 100.2%)">
          <b>Edit Profile</b>
        </a>
        <br />
        <br />
        <a href="javascript:void(0)" @click.prevent="deleteUser()" class="btn" style="border-radius: 15px; 
            background: linear-gradient(to right, #e73827, #f85032)">
          <b>Delete Profile</b>
        </a>
      </div>
    </div>
    <div v-else>
      <div class="col-md-2">
        <div v-if="isFollower()">
          <a href="javascript:void(0)" @click.prevent="unfollowRequest()"
          class="btn" style="border-radius: 15px; background: linear-gradient(to right, #e73827, #f85032)">
            <b>UnFollow</b>
          </a><br /><br />
        </div>
        <div v-else>
          <a href="javascript:void(0)" @click.prevent="followRequest()" class="btn"
           style="border-radius: 15px;  background: linear-gradient(117.5deg, rgb(89, 233, 162) 20.5%, rgb(29, 209, 185) 100.2%)" >
            <b>Follow</b>
          </a>
        </div>
        </div>
    </div>
      <li v-for="(post, index) in post_info" :key="index">{{ post.title }}
        <article class="media content-section">
          <img class="rounded-circle article-img" :src="'../src/imagesb/post_pics/' + post.image">
          <div class="media-body">
            <div class="article-metadata">
              <a class="mr-2" href="javascript:void(0)" @click.prevent="userProfile(post.user_username)">{{
                post.user_username }}</a>
              <small class="text-muted">{{ post.date_posted }}</small>
            </div>
            <h2>
              <a class="article-title" href="javascript:void(0)" @click.prevent="goToPost(post.id)">{{ post.title }}</a>
            </h2><br>

            <div class="text-center">
              <img :src="'../src/images/post_pics/' + post.image" class="border shadow p-2" style="width:250px;" alt="">
            </div><br>
            <p class="article-content">{{ post.caption }}</p>
            <div v-if="show_comment" :id="'comments-' + post.id" v-for="(comment, subindex) in post.comment" :key="subindex">
              <div class="card">
                <div class="card-body" :id="'comments-expanded-'+post.id">
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <a href="javascript:void(0)" @click.prevent="userProfile(comment.author)">{{ comment.author }}</a>:
                      {{ comment.text }}
                    </div>
                    <div>
                      <small class="text-muted"> {{comment.date_commented}}</small>
                      <div class="btn-group" v-if="comment.author==current_username || post.user_username==current_username">
                        <a href="javascript:void(0)" @click.prevent="deleteComment(comment.id)" style="border-radius: 15px; 
            background: linear-gradient(to right, #e73827, #f85032)" class="btn btn-primary btn-sm my-2" role="button" mg-3>Delete</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <p class="card-text">              
                <small v-if="post.comment.length>0" @click="show_comment = !show_comment"  class="text-muted" data-toggle="collapse" data-target="#comments-{{post.id}}">
                  View {{post.comment.length}} Comments</small>
              <small class="text-muted" v-else>No Comments</small>
            </p>

            <form class="input-group mb-3" method="POST" @submit.prevent="addcoments(post.id)">
              <input type="text" id="text" name="text" class="form-control" v-model="newcomment"
                placeholder="Write a comment here!" />
              <button type="submit" class="btn btn-primary">Comment</button>
            </form>
          </div>
        </article>
      </li>
    </div>
</template>
<script>
import axios from 'axios'
import Navbar from './nav_bar.vue'
export default {
  name: 'Home',
  components: {
    Navbar
  },
  data() {
    return {
      show_comment:false,
      user_info: [],
      post_info: [],
      newcomment: '',
      follow: [],
      current_username: '',
      followerslength: '',
      followinglength: ''

    };
  },
  methods: {
    async deleteComment(commentid){
      const url = "http://127.0.0.1:5000/delete_comment/" + commentid;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.put(url, {},{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      location.reload()
    },
    async deleteUser(){
      const url = "http://127.0.0.1:5000/delete_user/"+this.current_username;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.post(url,{},{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (result.status == 200){
        localStorage.clear();
        this.$router.push({ name: 'login' })
      }
      else{
        localStorage.clear()
        this.$router.push({ name: "login" })
      }        
    },
    async followRequest(){
      const url = "http://127.0.0.1:5000/follow/";
      let token = localStorage.getItem('jwttoken')
      let result = await axios.post(url, {
        'follower_username': this.current_username,
        'following_username': this.user_info.username
      },{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (result.status == 200)
        location.reload()
      else{
        localStorage.clear()
        this.$router.push({ name: "login" })
      }
    },
    async unfollowRequest(){
      const url = "http://127.0.0.1:5000/unfollow/";
      let token = localStorage.getItem('jwttoken')
      let result = await axios.post(url, {
        'follower_username': this.current_username,
        'following_username': this.user_info.username
      },{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (result.status == 200)
        location.reload()
      else{
        localStorage.clear()
        this.$router.push({ name: "login" })
      }
        
    },
    isFollower(){
      for (let i = 0; i < this.followerslength; i++) {
      if (this.follow.followers[i].follower_username === this.current_username) {
        return true;
      }
    }
    return false;
    },    
    userProfile(username) {
      let user = localStorage.getItem('user-info')
      if (!user) {
        localStorage.clear();
        this.$router.push({ name: "login" })
      }
      localStorage.setItem('userprofile-info',username)
      location.reload()
    },
    goToPost(postid) {
        localStorage.setItem('post-info', postid)
        this.$router.push({ name: 'post' })
    },
    async addcoments(postid) {
      let token = localStorage.getItem('jwttoken')
      const url = "http://127.0.0.1:5000/write_comment/" + postid;
      let result = await axios.post(url, {
        'author': this.current_username,
        'text': this.newcomment
      },{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      }
      );
      location.reload()       
    }
  },
  async mounted() {
    try {
      let username = localStorage.getItem('userprofile-info')
      if (!username) {
        this.$router.push({ name: "home" })
      }
      let user = localStorage.getItem('user-info')
      if (!user) {
        localStorage.clear()
        this.$router.push({ name: "login" })
      }
      this.current_username = user
      let token = localStorage.getItem('jwttoken')
      const url = "http://127.0.0.1:5000/user/" + username;
      const result = await axios.get(url,{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if(result.status==200){
        this.user_info = result.data[0]
        this.post_info = result.data[1]
        this.follow = result.data[2]
        this.followerslength = this.follow.followers.length
        this.followinglength = this.follow.following.length
      }else{
        localStorage.clear()
        this.$router.push({ name: "login" })
      }
    } catch (error) {
      console.log(error)
    }

  }
}
</script>


<style>
@media (min-width: 1024px) {
  .userprofile {
    background-color: #52ACFF;
    background-image: linear-gradient(180deg, #52ACFF 25%, #FFE32C 100%);
  }
}
</style>