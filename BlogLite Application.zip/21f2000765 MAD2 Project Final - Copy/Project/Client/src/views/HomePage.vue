<template>
  <div>
    <Navbar />

    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> Home </title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
      <link rel="stylesheet" href="css/login.css}">
    </head>
    <li v-for="(post, index) in post_info" :key="index">{{ post.title }}
      <article class="media content-section">
        <img class="rounded-circle article-img" :src="'../src/imagesb/post_pics/' + post.image">
        <div class="media-body">
          <div class="article-metadata">
            <a class="mr-2" href="javascript:void(0)" @click.prevent="userProfile(post.user_username)">{{
              post.user_username }}</a>
            <small class="text-muted">{{ post.date_posted }}</small>
          </div>
          <h2>
            <a class="article-title" href="javascript:void(0)" @click.prevent="goToPost(post.id)">{{ post.title }}</a>
          </h2><br>

          <div class="text-center">
            <img :src="'../src/images/post_pics/' + post.image" class="border shadow p-2" style="width:250px;" alt="">
          </div><br>
          <p class="article-content">{{ post.caption }}</p>
          <div v-if="show_comment" :id="'comments-' + post.id" v-for="(comment, subindex) in post.comment" :key="subindex">
              <div class="card">
                <div class="card-body" :id="'comments-expanded-'+post.id">
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <a href="javascript:void(0)" @click.prevent="userProfile(comment.author)">{{ comment.author }}</a>:
                      {{ comment.text }}
                    </div>
                    <div>
                      <small class="text-muted"> {{comment.date_commented}}</small>
                      <div class="btn-group" v-if="comment.author==user_info.username || post.user_username==user_info.username">
                        <a href="javascript:void(0)" @click.prevent="deleteComment(comment.id)" style="border-radius: 15px; 
            background: linear-gradient(to right, #e73827, #f85032)" class="btn btn-primary btn-sm my-2" role="button" mg-3>Delete</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <p class="card-text">              
                <small v-if="post.comment.length>0" @click="show_comment = !show_comment"  class="text-muted" data-toggle="collapse" data-target="#comments-{{post.id}}">
                  View {{post.comment.length}} Comments</small>
              <small class="text-muted" v-else>No Comments</small>
            </p>
          <form class="input-group mb-3" method="POST" action="/write_comment/{{post.id}}"
            @submit.prevent="addcoments(post.id)">
            <input type="text" id="text" name="text" class="form-control" v-model="newcomment"
              placeholder="Write a comment here!" />
            <button type="submit" class="btn btn-primary">Comment</button>
          </form>
        </div>
      </article>
    </li>
  </div>
</template>
<script>
import axios from 'axios'
import Navbar from './nav_bar.vue'
export default {
  name: 'Home',
  components: {
    Navbar
  },
  data() {
    return {
      show_comment:false,
      user_info: [],
      post_info: [],
      newcomment: ''
    }
  },
  methods: {
    async deleteComment(commentid){
      const url = "http://127.0.0.1:5000/delete_comment/" + commentid;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.put(url, {},{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      location.reload()
    },
    userProfile(username) {
      localStorage.setItem('userprofile-info', username)
      this.$router.push({ name: 'userprofile' })
    },
    goToPost(postid) {
        localStorage.setItem('post-info', postid)
        this.$router.push({ name: 'post' })
    },
    async addcoments(postid) {
      const url = "http://127.0.0.1:5000/write_comment/" + postid;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.post(url, {
        'author': this.user_info.username,
        'text': this.newcomment
      },{
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      location.reload()
    }
  },
  async mounted() {
    try {
      let token = localStorage.getItem('jwttoken')
      console.log(token)
      let resultjwt = await axios.post('http://127.0.0.1:5000/login', {}, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (resultjwt.status == 200) {
        this.$router.push({ name: "home" })
      }
      let user = localStorage.getItem('user-info')
      const url = "http://127.0.0.1:5000/feed/" + user;
      console.log(url)
      const result = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (result.status == 200) {
        this.user_info = {
          'email': result.data.email,
          'username': result.data.username
        }
        this.post_info = result.data.posts
      }
    } catch (error) {
      console.log(error)
    }

  }
}
</script>

<style scoped>.home {
  background: linear-gradient(to right, #fc00ff, #00dbde)
}</style>