<template>
  <div class="post">
    <Navbar />

    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> {{ post.user_username }}'s Post </title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
      <link rel="stylesheet" href="css/login.css">
    </head>

    <article class="media content-section">
      <div>
        <img class="rounded-circle article-img" :src="'../src/imagesb/post_pics/' + post.image">
      </div>

      <div class="media-body">
        <div class="article-metadata">
          <a class="mr-2" href="javascript:void(0)" @click.prevent="userProfile(post.user_username)">{{ post.user_username
          }}</a>
          <small class="text-muted">{{ post.date_posted }}</small>
        </div>
        <h2 class="article-title" href="#">{{ post.title }}</h2>
        <div class="text-center">
          <img :src="'../src/images/post_pics/' + post.image" class="border shadow p-2" style="width:250px;" alt="">
        </div><br>
        <p class="article-content">{{ post.caption }}</p>

      </div>
    </article>

    <div v-if="show_comment" :id="'comments-' + post.id" v-for="(comment, subindex) in post.comment" :key="subindex">
              <div class="card">
                <div class="card-body" :id="'comments-expanded-'+post.id">
                  <div class="d-flex justify-content-between align-items-center">
                    <div>
                      <a href="javascript:void(0)" @click.prevent="userProfile(comment.author)">{{ comment.author }}</a>:
                      {{ comment.text }}
                    </div>
                    <div>
                      <small class="text-muted"> {{comment.date_commented}}</small>
                      <div class="btn-group" v-if="comment.author==current_username || post.user_username==current_username">
                        <a href="javascript:void(0)" @click.prevent="deleteComment(comment.id)" style="border-radius: 15px; 
            background: linear-gradient(to right, #e73827, #f85032)" class="btn btn-primary btn-sm my-2" role="button" mg-3>Delete</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <p class="card-text">              
                <small v-if="comment_len>0" @click="show_comment = !show_comment"  class="text-muted" data-toggle="collapse" data-target="#comments-{{post.id}}">
                  View {{comment_len}} Comments</small>
              <small class="text-muted" v-else>No Comments</small>
            </p>

    <form class="input-group mb-3" method="POST" @submit.prevent="addcoments(post.id)">
      <input type="text" id="text" name="text" class="form-control" v-model="newcomment"
        placeholder="Write a comment here!" />
      <button type="submit" class="btn btn-primary">Comment</button>
    </form>
    <div v-if="current_username == post.user_username">
      <form method="POST" @submit.prevent="deletePost()">
        <input class="btn btn-danger" type="submit" style="border-radius: 15px; 
            background: linear-gradient(to right, #e73827, #f85032)" value="Delete POST">
      </form>
    </div>


  </div>
</template>

<script>
import axios from 'axios'
import Navbar from './nav_bar.vue'
export default {
  name: 'Post',
  components: {
    Navbar
  },
  data() {
    return {
      comment_len:0,
      show_comment:false,
      current_username: '',
      post: []
    }
  },
  methods: {
    async deleteComment(commentid) {
      const url = "http://127.0.0.1:5000/delete_comment/" + commentid;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.put(url, {}, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      location.reload()
    },
    async deletePost() {
      const url = "http://127.0.0.1:5000/delete_post/" + this.post.id;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.put(url, {}, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (result.status == 200) {
        this.$router.push({ name: 'home' })
      }
    },
    userProfile(username) {
      localStorage.setItem('userprofile-info', username)
      this.$router.push({ name: 'userprofile' })
    },
    async addcoments(postid) {
      const url = "http://127.0.0.1:5000/write_comment/" + postid;
      let token = localStorage.getItem('jwttoken')
      let result = await axios.post(url, {
        'author': this.current_username,
        'text': this.newcomment
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      location.reload()
    }
  },
  async mounted() {
    const postid = localStorage.getItem('post-info')
    this.current_username=localStorage.getItem('user-info')
    const url = "http://127.0.0.1:5000/post/" + postid;
    const token = localStorage.getItem('jwttoken')
    const result = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    this.post=result.data
    this.comment_len=this.post.comment.length
  }
}
</script>

<style>
@media (min-width: 1024px) {
  .post {
    background-color: #c6ffdd;
    background-image: linear-gradient(to right, #c6ffdd, #fbd786, #f7797d);
  }
}
</style>