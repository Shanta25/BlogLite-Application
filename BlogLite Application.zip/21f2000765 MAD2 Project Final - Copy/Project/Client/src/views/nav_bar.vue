<template>
    <body>
        <div id="app">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/">BlogLite</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="navbar-nav">
                        <li v-if="loggedIn"><a class="nav-item nav-link" href="/">Home</a></li>
                        <li v-if="loggedIn"><a class="nav-item nav-link" href="/newpost">New Post</a></li>
                        <li v-if="loggedIn"><a class="nav-item nav-link" href="javascript:void(0)"
                                @click.prevent="userProfile()">Profile</a></li>
                        <li v-if="loggedIn"> <a class="nav-item nav-link" href="/updateprofile">Update Profile</a></li>
                        <li v-if="loggedIn"><a class="nav-item nav-link" v-on:click="logout" href="#">Logout</a></li>
                        <li v-if="!loggedIn"><a class="nav-item nav-link" href="/login">Login</a></li>
                        <li v-if="!loggedIn"><a class="nav-item nav-link" href="/signup">Sign Up</a></li>
                        <form @submit.prevent="search" class="d-flex" role="search" v-if="loggedIn">
                            <input class="form-control me-2" type="search" v-model="searchString" placeholder="Search"
                                aria-label="Search">
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </nav>

            <div class="p-5 bg-secondary text-dark text-center"
                style="background-image: url('https://cdn.dribbble.com/users/501986/screenshots/15114330/media/784cd68582196119705c34e5a0c00e2c.gif');">
                <h1 style="color:black;"><b>BlogLite Application</b></h1>
                <p style="color:black;"><b>Aspiring Social Media Platform</b></p>
            </div>


        </div>

        <RouterView />
    </body>
</template>
<script>
import axios from 'axios';
export default {
    name: 'Navbar',
    data() {
        return {
            loggedIn: true,
            searchString: ''
        }
    },
    methods: {
        async search() {
            const url = "http://127.0.0.1:5000/search/" + this.searchString;
            let token = localStorage.getItem('jwttoken')
            const result = await axios.get(url, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (result.status == 200) {
                localStorage.setItem('userprofile-info', this.searchString)
                this.$router.push({ name: 'userprofile' })
                window.location.href = 'http://localhost:5173/userprofile';
            } else {
                alert("Incorrect username")
                location.reload()
            }
        },
        userProfile() {
            let username = localStorage.getItem('user-info')
            if (!username) {
                localStorage.clear();
                this.$router.push({ name: "login" })
            }
            localStorage.setItem('userprofile-info', username)
            // this.$router.push({ name: 'userprofile' })
            window.location.href="/userprofile";
        },
        logout() {
            localStorage.clear();
            this.$router.push({ name: 'login' });
        }
    },
    mounted() {
        let user = localStorage.getItem('user-info')
        if (user)
            this.loggedIn = true
        else
            this.loggedIn = false;
    }
}
</script>
  
  
  
  
  
  
  