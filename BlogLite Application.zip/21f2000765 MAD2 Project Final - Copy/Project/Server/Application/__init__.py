import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_restful import Api, Resource
from Application.config import LocalDevelopmentConfig
from flask_caching import Cache
from flask_cors import CORS

app = Flask(__name__)
app.config.from_object(LocalDevelopmentConfig)
cors = CORS(app, resources={r"/*": {"origins": ["http://localhost:5173","http://127.0.0.1:5000"]}})

cache = Cache(app)
app.app_context().push()

db = SQLAlchemy()
db.init_app(app)
app.app_context().push()

from Application.workers import celery, ContextTask
celery.conf.update(
    broker_url = "redis://localhost:6379/1",
    result_backend = "redis://localhost:6379/2"
)
celery.conf.enable_utc = False
celery.conf.timezone = "Asia/Calcutta"
celery.Task = ContextTask
app.app_context().push()

bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

app.app_context().push()

from Application import controllers, tasks

