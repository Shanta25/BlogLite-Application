import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config(object):
    DEBUG = False
    SECRET_KEY = None
    SQLITE_DB_DIR = None
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = None
    CORS_HEADERS = "Content-Type"
    SECURITY_TOKEN_AUTHENTICATION_HEADER = "Authentication-Token"
    WTF_CSRF_ENABLED = False
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_HOST = "localhost"
    CACHE_REDIS_PORT = 5173
    CACHE_DEFAULT_TIMEOUT = 300

class LocalDevelopmentConfig(Config):
    SQLITE_DB_DIR = basedir
    SQLALCHEMY_DATABASE_URI = 'sqlite:///database.db'
    DEBUG = True
    SECRET_KEY = os.urandom(12)
    SECURITY_PASSWORD_HASH = "bcrypt"
    SECURITY_PASSWORD_SALT = 'really super secret'
    SECURITY_REGISTRABLE = True
    SECURITY_CONFIRMABLE = False
    SECURITY_SEND_REGISTER_EMAIL = False
    SECURITY_UNAUTHORIZED_VIEW = None
