from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from flask_login import current_user
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import InputRequired, Length, Email, EqualTo, ValidationError
from .models import User


class LoginForm(FlaskForm):
    username = StringField('Username')
    password = PasswordField('Password')


class SignUpForm(FlaskForm):
    username = StringField('Username')
    email = StringField('Email')
    password = PasswordField('Password')

class EditProfileForm(FlaskForm):
    username = StringField('Username')
    email = StringField('Email')
    pro_pic = StringField('Update Profile Picture')
    password= PasswordField('Password')

class PostForm(FlaskForm):
    author=StringField('author')
    title = StringField('Title')
    caption = StringField('Caption')
    post_pic = StringField('image')


# class FollowForm(FlaskForm):
#     submit = SubmitField('Proceed')


class SearchForm(FlaskForm):
    searched = StringField('Searched', validators=[InputRequired()])
    submit = SubmitField('Submit')

