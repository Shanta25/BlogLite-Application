from datetime import datetime
from . import db, login_manager
from flask_login import UserMixin


@login_manager.user_loader
def load_user(user_username):
    return User.query.get(str(user_username))


class User(db.Model, UserMixin):
    username = db.Column(db.String(20), primary_key=True)
    email = db.Column(db.String(30), unique=True, nullable=False)
    image = db.Column(db.String(20), nullable=False, default='default_image.jpg')
    password = db.Column(db.String(60), nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)
    comments = db.relationship('Comment', backref='user', lazy=True)
    likes = db.relationship('Like', backref='user', lazy=True)



class Followers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    follower_username = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)
    followed_username = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.now)
    image = db.Column(db.String(20), default='default_post_pic.jpg')
    caption = db.Column(db.Text, nullable=False)
    user_username = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)
    comments = db.relationship('Comment', backref='post', lazy=True)
    likes = db.relationship('Like', backref='post', lazy=True)
    
    def __repr__(self):
        return f"Post('{self.title}', '{self.date_posted}')"

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(200), nullable=False)
    date_commented = db.Column(db.DateTime(timezone=True), default=datetime.now)
    author = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id', ondelete="CASCADE"))


class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_liked = db.Column(db.DateTime(timezone=True), default=datetime.now)
    author = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id', ondelete="CASCADE"))


class Actions(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, db.ForeignKey('user.username', ondelete="CASCADE"), nullable=False)
    job = db.Column(db.String(50), nullable=False)
    time = db.Column(db.DateTime(timezone=True), default=datetime.now)