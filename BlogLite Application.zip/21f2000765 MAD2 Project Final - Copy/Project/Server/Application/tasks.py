from Application.workers import celery
from flask import current_app as app
from . import db
from Application.models import *
from celery.schedules import crontab
from Application.models import * 
from flask_caching import Cache
import requests, os
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email import encoders
import smtplib
import datetime
from weasyprint import HTML
from jinja2 import Template
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

SMTP_SERVER_HOST = "localhost"
SMTP_SERVER_PORT = 1025
SENDER_ADDRESS = "mad2bloglite@gmail.com"
SENDER_PASSWORD = ""

def checklogin(user):
    today = datetime.datetime.now().minute
    logins = Actions.query.filter_by(username=user.username, job='login').all()
    for login in logins:
        if login.time.minute == today:
            return True
    return False

def checkpost(user):
    today = datetime.datetime.now().day
    posts = Post.query.filter_by(user_username=user.username).all()
    for post in posts:
        if post.date_posted.day == today:
            return True
    return False

def send_mail(to_address, subject, message, attachment_file=None):
    msg = MIMEMultipart()
    msg["From"] = SENDER_ADDRESS
    msg["To"] = to_address
    msg["Subject"] = subject
    msg.attach(MIMEText(message,"html")) 
        
    if attachment_file : 
        with open(attachment_file,"rb") as attachment : 
            part = MIMEBase("application","octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition", f"attachment; filename= {os.path.basename(attachment)}")
        msg.attach(part)

    s = smtplib.SMTP(host=SMTP_SERVER_HOST, port=SMTP_SERVER_PORT)
    s.login(SENDER_ADDRESS,SENDER_PASSWORD)
    s.send_message(msg)
    s.quit()


@celery.task()
def send_reminders():
    users = User.query.all()
    receivers = []
    for user in users:
        if not checklogin(user):
            with open(os.path.join(os.path.dirname(__file__), 'templates', 'RemindertoLogin.html')) as reminder:
                template = Template(reminder.read())
                message = template.render(user=user)
            receivers.append({"username": user.username, "email": user.email, "subject": "Login Reminder",
                               "message": message})
        elif checklogin(user) and not checkpost(user):
            with open(os.path.join(os.path.dirname(__file__), 'templates', 'RemindertoPost.html')) as reminder:
                template = Template(reminder.read())
                message = template.render(user=user)
            receivers.append({"username": user.username, "email": user.email, "subject": "Post Reminder",
                               "message": message})

    for receiver in receivers:
        send_mail(to_address=receiver["email"], subject=receiver["subject"], message=receiver["message"])


@celery.task()
def send_reports():
    users = User.query.all()
    receivers=[]
    now = datetime.datetime.now() - datetime.timedelta(days=1)
    month = now.strftime("%B")
    monthago = now - datetime.timedelta(days=30)
    jobs = ["login", "followers", "followings"]
    for user in users:
        user_jobs = []
        for job in jobs:
            if job=="login":
                total_logins = len([item.time for item in db.session.query(Actions).filter_by(username=user.username, job=job).
                            filter(Actions.time>monthago).all()])
            elif job=="followings":
                total_followings = len([item.time for item in db.session.query(Actions).filter_by(username=user.username, job=job).
                            filter(Actions.time>monthago).all()])
            elif job=="followers":
                total_followers = len([item.time for item in db.session.query(Actions).filter_by(username=user.username, job=job).
                            filter(Actions.time>monthago).all()])
        total_posts= len([item.time for item in db.session.query(Post).filter_by(user_username=user.username).
                           filter(Post.date_posted>monthago).all()])
        user_jobs.append({"total_logins":total_logins,
                          "total_followings":total_followings,
                          "total_followers":total_followers, 
                          "total_posts":total_posts})
        with open(os.path.join(os.path.dirname(__file__), 'templates', 'MonthlyReport.html')) as report:
            template = Template(report.read())
            message = template.render(user=user, user_jobs=user_jobs)
            receivers.append({"username": user.username, "email": user.email, "subject": "Monthly Engagement Report",
                               "message": message})
    
    for receiver in receivers:
        send_mail(to_address=receiver["email"], subject=receiver["subject"], message=receiver["message"])   
        
        
@celery.task()
def export_csv(username):
    user = User.query.get(username)
    posts = Post.query.filter_by(user_username=username).all()
    posts_no = len(posts)
    followers_no = len(Followers.query.filter_by(followed_username=username).all())
    followings_no = len(Followers.query.filter_by(follower_username=username).all())
    user_data = {
        "Username": user.username,
        "Email": user.email,
        "Number of Posts": posts_no,
        "Number of Followers": followers_no,
        "Number of Followings": followings_no
    }
    posts_data = {
        "Post Title": [post.title for post in posts],
        "Post Image": [post.image for post in posts], 
        "Post Caption": [post.caption for post in posts],
        "Post Date": [post.date_posted for post in posts]
    }
    user_df = pd.DataFrame([user_data])
    posts_df = pd.DataFrame(posts_data)
    user_file = os.path.join(os.path.dirname(__file__), 'static', 'csvs', "{username}.csv".format(username=user.username))
    post_file = os.path.join(os.path.dirname(__file__), 'static', 'csvs', "{username}_posts.csv".format(username=user.username))
    user_df.to_csv(user_file, index=False)
    posts_df.to_csv(post_file, index=False)
    with open(os.path.join(os.path.dirname(__file__), 'templates',
                           'CSVfile.html')) as file_:
        template = Template(file_.read())
        message = template.render(user=user)
    send_mail(to_address=user.email, subject="User Details",
              message=message, attachments=[os.path.join(os.path.dirname(__file__), 'static', 'csvs', "{username}.csv".format(username=user.username)),
                                            os.path.join(os.path.dirname(__file__), 'static', 'csvs', "{username}_posts.csv".format(username=user.username))
                                            ])


@celery.on_after_finalize.connect
def periodic_tasks(sender, **kwargs):

    sender.add_periodic_task(crontab(hour=12, minute=33),
                             send_reminders.s(),
                             name="Daily Reminder")

    sender.add_periodic_task(crontab(day_of_month=1, hour=0, minute=0),
                             send_reports.s(),
                             name="Monthly Report")