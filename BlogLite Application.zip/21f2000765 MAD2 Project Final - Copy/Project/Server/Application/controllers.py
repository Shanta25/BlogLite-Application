import os
import secrets
from PIL import Image
from flask import render_template, url_for, redirect, request, flash, abort,jsonify,make_response
from flask_login import login_user, logout_user, login_required, current_user
from .models import User, Post, Comment, Like, Followers, Actions
from .forms import LoginForm, SignUpForm, EditProfileForm, PostForm,  SearchForm
from . import app, db, bcrypt
from datetime import datetime
import json
from sqlalchemy import not_
import jwt


@app.route("/login", methods=['POST'])
def login():
    if (request.method=='POST'):
        try:
            token=request.headers.get('Authorization')
            secret_key = 'shanta'
            print(token)
            if token:
                token=token[7:]
                print(token)
                payload = jwt.decode(token, secret_key, algorithms=['HS256'])
                if payload:
                    resp=make_response("ok")
                    resp.status_code=200
                    return resp
            form = LoginForm()
            user = User.query.filter_by(username=form.username.data).first()
            if user and bcrypt.check_password_hash(user.password, form.password.data):
                emailVerify={"username":form.username.data}
                jwttoken= jwt.encode(emailVerify, secret_key, algorithm='HS256')
                data={'username':form.username.data,'jwttoken':jwttoken}
                print(data)
                resp=make_response(jsonify(data))
                resp.status_code=200
                action = Actions(username=form.username.data, job="login")
                db.session.add(action)
                db.session.commit()
            else:
                resp=make_response('Login UnSuccessful')
                resp.status_code=203
        except Exception as e:
            resp=make_response(str(e))
            resp.status_code=203
        finally:
            return resp

@app.route("/signup", methods=['POST'])
def signup():
    try:
        form=SignUpForm()
        print(form.data)
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        data={'username':form.username.data}
        secret_key = 'shanta'
        token = jwt.encode(data, secret_key, algorithm='HS256')
        data={
            'username':form.username.data,
            'jwttoken':token
        }
        resp=make_response(jsonify(data))
        resp.status_code=200
    except Exception as e:
        resp=make_response(str(e))
        resp.status_code=203
    finally:   
        return resp   

@app.route("/user/<username>")
def user(username):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        user = User.query.filter_by(username=username).first_or_404()
        posts = Post.query.filter_by(author=user)\
            .order_by(Post.date_posted.desc())
        followers= Followers.query.filter_by(followed_username=username)
        followed= Followers.query.filter_by(follower_username=username)
        user_json={
        'username':user.username,
        'email':user.email
        }
        flwrs=[]
        flwds=[]
        for follower in followers:
            flwr={
                'follower_username':follower.follower_username
            }
            flwrs.append(flwr)
        for follower in followed:
            flwd={
                'following_username':follower.followed_username
            }
            flwds.append(flwd)
        follow_json={
            'followers':flwrs,
            'following':flwds
        }

        posts_json=[]
        for post in posts:
            comments=[]
            likes=[]
            for comment in post.comments:
                comm={
                    'id':comment.id,
                    'text':comment.text,
                    'date_commented':comment.date_commented,
                    'author':comment.author,
                    'post_id':comment.post_id
                }
                comments.append(comm)
            for like in post.likes:
                lik={
                    'id':like.id,
                    'date_liked':like.date_liked,
                    'author':like.author,
                    'post_id':like.post_id
                }
                likes.append(lik)
                        
            post_json={
                'id':post.id,
                'title':post.title,
                'date_posted':post.date_posted,
                'image':post.image,
                'caption':post.caption,
                'like':likes,
                'comment':comments,
                'user_username':post.user_username
            }
            posts_json.append(post_json)  
        print(posts_json, follow_json)  
        resp=[user_json,posts_json, follow_json]
        return resp
    except:
        resp=make_response("Invalid Username")
        resp.status_code=203
    finally:
        return resp


@app.route("/update_profile/<username>", methods=['PUT'])
def update_profile(username):
    token=request.headers.get('Authorization')
    secret_key = 'shanta'
    print(token)
    if token:
        token=token[7:]
        print(token)
        payload = jwt.decode(token, secret_key, algorithms=['HS256'])
    req_data =request.get_data().decode('utf-8')
    data=json.loads(req_data)
    user = User.query.filter_by(username=username).first_or_404()
    if 'username' in data:
        user.username = data['username']
    if 'email' in data:
        user.email = data['email']
    if 'password' in data:
        hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        user.password = hashed_password
    if 'pro_pic' in data:
        user.image = data['pro_pic']

    try:
        db.session.commit()
        return jsonify({'message': 'User updated successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': str(e)}), 203



@app.route("/delete_user/<username>", methods=['POST'])
def delete_user(username):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        user = User.query.filter_by(username=username).first()
        if not user:
            resp=make_response('Error')
            resp.status_code=203
        else:
            db.session.delete(user)
            db.session.commit()
            resp=make_response('User Deleted Successfully')
    except:
        resp=make_response("Error")
        resp.status_code=203
    finally:
        return resp


@app.route('/follow/', methods=['POST'])
def follow():
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        data=json.loads(request.data)
        print(data)
        follower_username=data['follower_username']
        following_username=data['following_username']
        user1 = User.query.filter_by(username=follower_username).first_or_404()
        user2=User.query.filter_by(username=following_username).first_or_404()
        follower = Followers(follower_username=follower_username, followed_username=following_username)
        db.session.add(follower)
        db.session.commit()

        flwds = Actions(username=follower_username, job="followings")
        db.session.add(flwds)
        db.session.commit()

        flwrs = Actions(username=following_username, job="followers")
        db.session.add(flwrs)
        db.session.commit()

        resp=make_response("Done")
    except:
        resp=make_response("Error")
        resp.status_code=203
    finally:
        return resp



@app.route('/unfollow/', methods=['POST'])
def unfollow():
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        data=json.loads(request.data)
        print(data)
        follower_username=data['follower_username']
        following_username=data['following_username']
        user1 = User.query.filter_by(username=follower_username).first_or_404()
        user2=User.query.filter_by(username=following_username).first_or_404()
        follower = Followers.query.filter_by(follower_username=follower_username, followed_username=following_username).first()
        if follower:
            db.session.delete(follower)
            db.session.commit()
        resp=make_response("Done")
    except Exception as e:
        resp=make_response(str(e))
        resp.status_code=203
    finally:
        return resp

from Application import cache
@cache.cached(key_prefix="getPosts()")
def getPosts():
    return Post.query.all()

@cache.memoize()
def getPostsByUsername(username):
    return Post.query.filter_by(user_username=username).all()


@app.route("/new-post", methods=['GET', 'POST'])
def new_post():
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        print(request.data)
        form=PostForm()
        print(form.data)
        post = Post(title=form.title.data, caption=form.caption.data, user_username=form.author.data, image=form.post_pic.data,comments=[],likes=[])       
        db.session.add(post)
        db.session.commit()
        cache.delete_memoized(getPostsByUsername, post.user_username)
        resp=make_response("Correct")
        resp.status_code=200
    except:
        resp=make_response('Missing Data')
        resp.status_code=203
    finally:   
        return resp        

@app.route("/delete_post/<post_id>", methods=['PUT'])
def delete_post(post_id):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        post = Post.query.get_or_404(post_id)
        db.session.delete(post)
        db.session.commit()
        cache.delete_memoized(getPostsByUsername, post.user_username)
        resp=make_response("Deleted")
    except:
        resp=make_response("Error")
        resp.status_code=203
    finally:
        return resp



@app.route("/feed/<username>")
def user_posts(username):
    try:
        user = User.query.filter_by(username=username).first_or_404()
        posts = Post.query.filter(not_(Post.author==user))\
            .order_by(Post.date_posted.desc())
        
        posts_json=[]
        for post in posts:
            comments=[]
            likes=[]
            for comment in post.comments:
                comm={
                    'id':comment.id,
                    'text':comment.text,
                    'date_commented':comment.date_commented,
                    'author':comment.author,
                    'post_id':comment.post_id,

                }
                comments.append(comm)
            for like in post.likes:
                lik={
                    'id':like.id,
                    'date_liked':like.date_liked,
                    'author':like.author,
                    'post_id':like.post_id
                }
                likes.append(lik)
                        
            post_json={
                'id':post.id,
                'title':post.title,
                'date_posted':post.date_posted,
                'image':post.image,
                'caption':post.caption,
                'like':likes,
                'comment':comments,
                'user_username':post.user_username
            }
            posts_json.append(post_json) 
        user_json={
            'username':user.username,
            'email':user.email,
            'posts':posts_json
        }
        return user_json         
    except:
        resp=make_response()
        resp.status_code=203
        return resp



@app.route('/search/<username>')
def search(username):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        user = User.query.filter_by(username=username).first_or_404()
        resp=make_response("Valid User")
    except:
        resp=make_response("Invalid User")
        resp.status_code=202
    finally:
        return resp


@cache.cached(key_prefix="getComments()")
def getComments():
    return Comment.query.all()

@cache.memoize()
def getCommentsByUsername(username):
    return Comment.query.filter_by(author=username).all()


@app.route("/write_comment/<post_id>", methods=['POST'])
def write_comment(post_id):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        print(token)
        if token:
            token=token[7:]
            print(token)
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        dat=json.loads(request.data)
        text=dat['text']
        post = Post.query.filter_by(id=post_id)
        if post:
            comment = Comment(text=text, author=dat['author'], post_id=post_id)
            db.session.add(comment)
            db.session.commit()
            cache.delete_memoized(getCommentsByUsername, comment.author)
            resp=make_response("new comment")
    except:
        resp=make_response("Error")
        resp.status_code=203
    finally:
        return resp


@app.route("/delete_comment/<comment_id>", methods=['PUT'])
def delete_comment(comment_id):
    try:
        token=request.headers.get('Authorization')
        secret_key = 'shanta'
        token=token[7:]
        print(token)
        payload = jwt.decode(token, secret_key, algorithms=['HS256'])
        comment = Comment.query.filter_by(id=comment_id).first_or_404()
        db.session.delete(comment)
        db.session.commit()
        cache.delete_memoized(getCommentsByUsername, comment.author)
        resp=make_response("deleted")
        resp.status_code=200
    except:
        resp=make_response("error")
        resp.status_code=203
    finally:
        return resp


@app.route("/like/<post_id>", methods=['GET'])
@login_required
def like(post_id):
    post = Post.query.filter_by(id=post_id).first()
    like = Like.query.filter_by(author=current_user.id, post_id=post_id).first()

    if not post:
        flash('Post does not exist.', category='error')

    elif like:
        db.session.delete(like)
        db.session.commit()
        
    else:
        like = Like(author=current_user.id, post_id=post_id)
        db.session.add(like)
        db.session.commit()